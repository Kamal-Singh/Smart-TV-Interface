export const SET_TOKEN = "SET_TOKEN";
export const LOGOUT = "LOGOUT";
export const NEXT_MODULE = "NEXT_MODULE";
export const PREVIOUS_MODULE = "PREVIOUS_MODULE";
export const CHANGE_MODULE = "CHANGE_MODULE";
export const NEXT_TILE = "NEXT_TILE";
export const PREVIOUS_TILE = "PREVIOUS_TILE";
export const SET_LENGTH = "SET_LENGTH";
