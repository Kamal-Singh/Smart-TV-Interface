import React from "react";
import "./App.css";
import Layout from "./hoc/Layout/Layout";

function App() {
  return <Layout />;
}

export default App;
