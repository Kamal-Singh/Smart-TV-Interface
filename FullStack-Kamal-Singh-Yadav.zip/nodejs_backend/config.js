module.exports = {
  JWT_SECRET: "dahjsdhafjaklsdjflkajsfdlkjasldkfj84urj90uf90asd0f98a90s8dfasdf",
  SERVER_PORT: 3000,
  DATABASE_URL: "mongodb://test:test123@ds115166.mlab.com:15166/smarttv",
  EXPIRE_TIME: 86400,
};
